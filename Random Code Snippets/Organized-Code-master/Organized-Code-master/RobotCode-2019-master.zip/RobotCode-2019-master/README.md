# RobotCode-2019
Robot code for 2019 FRC

Name the servers for the ports. Don't let the program figure out the names
